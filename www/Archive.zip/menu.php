<div id="navMenu">
  <table width="700" border="0" cellspacing="0" cellpadding="0">
    <tr>
      <td width="175" align="center" valign="middle"><div align="center"><a href="index.htm">Home</a></div></td>
      <td width="175" align="center" valign="middle"><div align="center"><a href="description.php">Description</a></div></td>
      <td width="175" align="center" valign="middle"><div align="center"><a href="features.php">Features</a></div></td>
	  <td width="175" align="center" valign="middle"><div align="center"><a href="news.php">What's New </a></div></td>
    </tr>
    <tr>
      <td width="175" align="center" valign="middle"><div align="center"><a href="installation.php">Installation</a></div></td>
      <td width="175" align="center" valign="middle"><div align="center"><a href="downloads.php">Downloads</a></div></td>
      <td width="175" align="center" valign="middle"><div align="center"><a href="screens.php">Screen Shots </a></div></td>
	  <td width="175" align="center" valign="middle"><div align="center"><a href="links.php">Links</a></div></td>
    </tr>
  </table>
</div>
